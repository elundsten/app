# Projekt

Ni ska lämna in er kod till projektet här. Det är okej att även ha projektet publikt på github om ni vill, men då behöver ni även pusha projektet hit. Behöver ni hjälp med git är ni välkomna att fråga assistenterna.

Innan ni börjar på projektet behöver ni få er projektspecifikation godkänd. Ni lämnar in den på canvas här: https://kth.instructure.com/courses/4240/assignments/21920 Om ni är flera som jobbar tillsammans så behöver bara en lämna in uppgiften

Tänk på att hålla en någolunda snygg och tydlig githistorik där det syns att alla jobbat på projektet. Försök att hålla commits så små som möjligt (atomic). 

